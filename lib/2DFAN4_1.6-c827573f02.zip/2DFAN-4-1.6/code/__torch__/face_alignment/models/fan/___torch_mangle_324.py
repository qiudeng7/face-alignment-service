class HourGlass(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  b1_4 : __torch__.face_alignment.models.fan.___torch_mangle_239.ConvBlock
  b2_4 : __torch__.face_alignment.models.fan.___torch_mangle_246.ConvBlock
  b1_3 : __torch__.face_alignment.models.fan.___torch_mangle_253.ConvBlock
  b2_3 : __torch__.face_alignment.models.fan.___torch_mangle_260.ConvBlock
  b1_2 : __torch__.face_alignment.models.fan.___torch_mangle_267.ConvBlock
  b2_2 : __torch__.face_alignment.models.fan.___torch_mangle_274.ConvBlock
  b1_1 : __torch__.face_alignment.models.fan.___torch_mangle_281.ConvBlock
  b2_1 : __torch__.face_alignment.models.fan.___torch_mangle_288.ConvBlock
  b2_plus_1 : __torch__.face_alignment.models.fan.___torch_mangle_295.ConvBlock
  b3_1 : __torch__.face_alignment.models.fan.___torch_mangle_302.ConvBlock
  b3_2 : __torch__.face_alignment.models.fan.___torch_mangle_309.ConvBlock
  b3_3 : __torch__.face_alignment.models.fan.___torch_mangle_316.ConvBlock
  b3_4 : __torch__.face_alignment.models.fan.___torch_mangle_323.ConvBlock
  def forward(self: __torch__.face_alignment.models.fan.___torch_mangle_324.HourGlass,
    input: Tensor) -> Tensor:
    _0 = self.b3_4
    _1 = self.b3_3
    _2 = self.b3_2
    _3 = self.b3_1
    _4 = self.b2_plus_1
    _5 = self.b2_1
    _6 = self.b1_1
    _7 = self.b2_2
    _8 = self.b1_2
    _9 = self.b2_3
    _10 = self.b1_3
    _11 = self.b2_4
    _12 = (self.b1_4).forward(input, )
    input0 = torch.avg_pool2d(input, [2, 2], [2, 2], [0, 0], False, True, None)
    _13 = (_11).forward(input0, )
    _14 = (_10).forward(_13, )
    input1 = torch.avg_pool2d(_13, [2, 2], [2, 2], [0, 0], False, True, None)
    _15 = (_9).forward(input1, )
    _16 = (_8).forward(_15, )
    input2 = torch.avg_pool2d(_15, [2, 2], [2, 2], [0, 0], False, True, None)
    _17 = (_7).forward(input2, )
    _18 = (_6).forward(_17, )
    input3 = torch.avg_pool2d(_17, [2, 2], [2, 2], [0, 0], False, True, None)
    _19 = (_4).forward((_5).forward(input3, ), )
    _20 = (_3).forward(_19, )
    _21 = ops.prim.NumToTensor(torch.size(_20, 2))
    _22 = torch.to(_21, 6, False, False, None)
    _23 = torch.to(CONSTANTS.c0, torch.device("cpu"), 6, False, False, None)
    _24 = torch.to(torch.mul(_22, torch.detach(_23)), 6, False, False, None)
    _25 = int(torch.floor(_24))
    _26 = ops.prim.NumToTensor(torch.size(_20, 3))
    _27 = torch.to(_26, 6, False, False, None)
    _28 = torch.to(CONSTANTS.c0, torch.device("cpu"), 6, False, False, None)
    _29 = torch.to(torch.mul(_27, torch.detach(_28)), 6, False, False, None)
    up2 = torch.upsample_nearest2d(_20, [_25, int(torch.floor(_29))], 2., 2.)
    input4 = torch.add(_18, up2, alpha=1)
    _30 = (_2).forward(input4, )
    _31 = ops.prim.NumToTensor(torch.size(_30, 2))
    _32 = torch.to(_31, 6, False, False, None)
    _33 = torch.to(CONSTANTS.c0, torch.device("cpu"), 6, False, False, None)
    _34 = torch.to(torch.mul(_32, torch.detach(_33)), 6, False, False, None)
    _35 = int(torch.floor(_34))
    _36 = ops.prim.NumToTensor(torch.size(_30, 3))
    _37 = torch.to(_36, 6, False, False, None)
    _38 = torch.to(CONSTANTS.c0, torch.device("cpu"), 6, False, False, None)
    _39 = torch.to(torch.mul(_37, torch.detach(_38)), 6, False, False, None)
    up20 = torch.upsample_nearest2d(_30, [_35, int(torch.floor(_39))], 2., 2.)
    input5 = torch.add(_16, up20, alpha=1)
    _40 = (_1).forward(input5, )
    _41 = ops.prim.NumToTensor(torch.size(_40, 2))
    _42 = torch.to(_41, 6, False, False, None)
    _43 = torch.to(CONSTANTS.c0, torch.device("cpu"), 6, False, False, None)
    _44 = torch.to(torch.mul(_42, torch.detach(_43)), 6, False, False, None)
    _45 = int(torch.floor(_44))
    _46 = ops.prim.NumToTensor(torch.size(_40, 3))
    _47 = torch.to(_46, 6, False, False, None)
    _48 = torch.to(CONSTANTS.c0, torch.device("cpu"), 6, False, False, None)
    _49 = torch.to(torch.mul(_47, torch.detach(_48)), 6, False, False, None)
    up21 = torch.upsample_nearest2d(_40, [_45, int(torch.floor(_49))], 2., 2.)
    input6 = torch.add(_14, up21, alpha=1)
    _50 = (_0).forward(input6, )
    _51 = ops.prim.NumToTensor(torch.size(_50, 2))
    _52 = torch.to(_51, 6, False, False, None)
    _53 = torch.to(CONSTANTS.c0, torch.device("cpu"), 6, False, False, None)
    _54 = torch.to(torch.mul(_52, torch.detach(_53)), 6, False, False, None)
    _55 = int(torch.floor(_54))
    _56 = ops.prim.NumToTensor(torch.size(_50, 3))
    _57 = torch.to(_56, 6, False, False, None)
    _58 = torch.to(CONSTANTS.c0, torch.device("cpu"), 6, False, False, None)
    _59 = torch.to(torch.mul(_57, torch.detach(_58)), 6, False, False, None)
    up22 = torch.upsample_nearest2d(_50, [_55, int(torch.floor(_59))], 2., 2.)
    return torch.add(_12, up22, alpha=1)
